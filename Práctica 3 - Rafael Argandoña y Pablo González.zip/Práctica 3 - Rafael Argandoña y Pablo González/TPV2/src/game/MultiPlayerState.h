#pragma once
#include "GameState.h"

class MultiPlayerState : public GameState {
private:

public:
	MultiPlayerState(Game* g);
};